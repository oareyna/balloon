function guessBoard = updateGuessBoard(guessBoard, numGuess, guessedColors)
% updates the guessBoard with the current guess of the player
% INPUTS: guessBoard - a 10x4 numeric array with values 1 to 9
%                      this is the Guess Board BEFORE the Player's
%                      current guess
%           numGuess - an integer between 1 and 10
%                      the Player can have max of 10 guesses
%      guessedColors - a 1x4 char Array from the set 'BGOKPRTY'
%                      this is the Player's current guess
%RETURNs: guessBoard - a 10x4 numeric array with values 1 to 9
%                      this is the Guess Board AFTER the Player's
%                      current guess, so the row at numGuess is updated
%                      with guessedColors
% The mapping of colors to values and characters
% Gray(A) = 1, Blue(B) = 2, Green(G) = 3; Orange(O) = 4, Pink(K) = 5,
% Purple(P) = 6, Red(R) = 7, Turquoise(T) = 8, Yellow(Y) = 9
% NOTE: THIS FUNCTION DOES NOT PRINT TO THE COMMAND WINDOW


% for 1 through the number of colors guessed it will check which letter it
% is then assign it to a number based on a letter
for i = 1 : length(guessedColors)
    if guessedColors(1,i) == 'A'
        % it will make the guess boards row be from the numGuess and the
        % column come from the which ever iteration i is on
        guessBoard(numGuess, i) = 1;
    elseif guessedColors(1,i) == 'B'
        guessBoard(numGuess, i) = 2;
    elseif guessedColors(1,i) == 'G'
        guessBoard(numGuess, i) = 3;
    elseif guessedColors(1,i) == 'O'
        guessBoard(numGuess, i) = 4;
    elseif guessedColors(1,i) == 'K'
        guessBoard(numGuess, i) = 5;
    elseif guessedColors(1,i) == 'P'
        guessBoard(numGuess, i) = 6;
    elseif guessedColors(1,i) == 'R'
        guessBoard(numGuess, i) = 7;
    elseif guessedColors(1,i) == 'T'
        guessBoard(numGuess, i) = 8;
    elseif guessedColors(1,i) == 'Y'
        guessBoard(numGuess, i) = 9;

    end
end


end