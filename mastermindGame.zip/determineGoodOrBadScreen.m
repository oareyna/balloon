function numOfWins = determineGoodOrBadScreen(numGuess)
% Checks whether the user will get the "bad" or "good" screen/animation
% INPUT: numGuess is a 1 by 1 integer matrix, the number of how many
% guesses the user has made
% RETURNS: numOfWins
%         0 - the users has lost because the numGuess is over 10
%         1 - the user has won

% pausing because this is right after the user has won or loss so i want
% the reader to read the text for a bit then have the function move on
% the pause function delays the program for the amount of seconds you put
% inbetween the parenthesis
pause(1.5);
% re initializing the board
numTotGuesses = 10;
sizeColorGuess = 4;
guessBoard = ones(numTotGuesses, sizeColorGuess);
resultsBoard = ones(numTotGuesses, sizeColorGuess);
% pausing
pause(0.1);
% showing the initialized board
showBoards(guessBoard, resultsBoard);
% pausing after showing
pause(0.1);
% if the user got less than or equal to 10, they have won
if numGuess <= 10
    % shows the user has won
    numOfWins = 1;
    % i want a rainbow coloring and the numbers I picked will represent a
    % rainbow design
    nums = [7 4 9 3 8 2 6 7 4 9 3 8 2];
    % i wanted a checkerboard pattern for the other side of the board so I
    % picked black and white
    nums2 = [2 3 2 3 2 3 2 3 2 3 2 3 2 ];
    % both arrays are 13 in size because that is number needed for 10 , 4
    % digit length arrays ( so 10 + 3)

    % for 1 to 10
    for i = 1 : 10
        % the left side will equal the numbers of the nums array based on i
        guessBoard(i, :) = nums(i:i+3);
        % the right side will equal the numbers of the nums array based on i
        resultsBoard(i,:) = nums2(i:i+3);
        % display the design
        showBoards(guessBoard, resultsBoard);
        % pause a little for each pattern
        pause(0.1);
    end


    % pause again to show off the design
    pause(0.1);

    % switch up the pattern
    nums = [4 9 3 8 2 6 7 4 9 3 8 2 6];
    nums2 = [3 2 3 2 3 2 3 2 3 2 3 2 3];
    % redo what just did, displaying and pausing but even faster
    for i = 1 : 10
        guessBoard(i, :) = nums(i:i+3);
        resultsBoard(i,:) = nums2(i:i+3);
        showBoards(guessBoard, resultsBoard);
        pause(0.01);
    end


else
    % the user has lost because they went over 10 guesses
    numOfWins = 0;
    % show them a bleak, gloomy pattern
    nums = [7 7 7 7 7 7 7 7 7 7 7 7 7 ];
    nums2 = [2 2 2 2 2 2 2 2 2 2 2 2 2 ];
    % for 1 through 10
    for i = 1 : 10
        % once again display then pause
        guessBoard(i, :) = nums(i:i+3);
        resultsBoard(i,:) = nums2(i:i+3);
        showBoards(guessBoard, resultsBoard);
        pause(0.1);
    end



end

end