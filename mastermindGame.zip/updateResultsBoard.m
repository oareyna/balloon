function resultsBoard = updateResultsBoard(resultsBoard, numGuess, numBlackPegs, numWhitePegs)
%updates the resultsBoard with the current guess of the player
% INPUTS: resultsBoard - a 10x4 numeric array with values 1 to 3
%                      this is the Results Board BEFORE the Player's
%                      current guess
%           numGuess - an integer between 1 and 10
%                      the Player can have max of 10 guesses
%      numBlackPegs(2) -  an integer between 0 and 4
%                      how many of the guessed colors are BLACK pegs
%      numWhitePegs(3) -  an integer between 0 and 4
%                      how many of the guessed colors are WHITE pegs
%RETURNs: resultsBoard - a 10x4 numeric array with values 1 to 3
%                      this is the Results Board AFTER the Player's
%                      current guess, so the row at numGuess is updated
%                      with current number of WHITE and BLACK pegs
% NOTE: THIS FUNCTION DOES NOT PRINT TO THE COMMAND WINDOW

% making sure it will go through 4 times since that is the max amount of
% numbers changed available
for i = 1 : 4
    % if the numBlackPegs does not equal 0, it will make the index 2 and
    % minus the numBlackPegs counters
    if numBlackPegs ~= 0
        resultsBoard(numGuess,i) = 2;
        numBlackPegs = numBlackPegs - 1;
        % if the numWhitePegs does not equal 0, it will make the index 3 and
        % minus the numWhitePegs counters
    elseif numWhitePegs ~= 0
        resultsBoard(numGuess,i) = 3;
        numWhitePegs = numWhitePegs - 1;

    end

end

end
