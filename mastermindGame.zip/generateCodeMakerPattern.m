function codeMakerPattern = generateCodeMakerPattern()
% Generates a random Secret Code for the Code Maker
% from the following 8-colors, color can be repeated
% Blue(B), Green(G), Orange(O), Pink(K), Purple(P),
% Red(R), Turquoise(T), Yellow(Y)
%
% RETURNS codeMakerPattern is a 1x4 char Array made of these colors

% haves all of the letter we will use in the game
colors = ['B' 'G' 'O' 'K' 'P' 'R' 'T' 'Y'];
% pre-allocating a matrix that has 4 zeros and making them into chars
codeMakerPattern = char(zeros(1,4));

% for 1 through 4, it is creating a random char in each index of the
% codeMakerPattern
for i = 1:4
    codeMakerPattern(1, i) = colors(1,randi([1,8],1));
end

end