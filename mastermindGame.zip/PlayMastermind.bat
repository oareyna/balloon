
@echo off
title Mastermind Game
cd /d "%~dp0"
matlab -nodesktop -nosplash -r "run('mastermindGame.m')"
pause

