function numWhitePegs = determineWhitePegs(newLook, newCode)
% counts the number of white pegs
% INPUT: newLook is a char array that contains the remaining letters of the
% user's guess after we count the number of black pegs
%        newCode is a char array that contains the remaining letters of the
%        codeMakers guess after we count the number of black pegs
% RETURNS: number of white pegs : numWhitePegs
%      Will return a number 0 through 4 determined by the amount of white
%      pegs

% initializes the number of white pegs
numWhitePegs = 0;
% for the length of the user guesses' new guess with the black peg letter
% taken out
for j = 1 : length(newLook)
    % if the new code if greater than or is equal to 1 and the indexes of
    % the letter are the same, add to the number of white pegs then get rid
    % of that letter in the new code
    if length(newCode) >= 1 && strcmpi(newLook(j), newCode(1))
        numWhitePegs = numWhitePegs + 1;
        newCode(1) = ' ';
    elseif length(newCode) >= 2 && strcmpi(newLook(j), newCode(2))
        numWhitePegs = numWhitePegs + 1;
        newCode(2) = ' ';
    elseif length(newCode) >= 3 && strcmpi(newLook(j), newCode(3))
        numWhitePegs = numWhitePegs + 1;
        newCode(3) = ' ';

    elseif length(newCode) >= 4 && strcmpi(newLook(j), newCode(4))
        numWhitePegs = numWhitePegs + 1;
        newCode(4) = ' ';
    end
end

end