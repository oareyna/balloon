function validity = checkPlayerColorInput(guessedColors)
% Checks the validity of the color guess of the player
% INPUT: guessedColors is a 1 by 4 char array, the player's guess
% RETURNS: validity
%         0 - Valid, 4 letters are from the set 'BGOKPRTY'
%         1 - INVALID, some non-letters in the guess
%         2 - INVALID, more or  less than 4 letters
%         3 - INVALID, 4 letters but not all from the set'BGOKPRTY'
% NOTE: This function does not print to the command window

% creating a matrix with valid letters
validLetters = ['B' 'G' 'O' 'K' 'P' 'R' 'T' 'Y'];
% making the user's guess uppercase
guessesColors = upper(guessedColors);
% a variable to see what type of valid it is and an isRunning to end it
% when any of the statements aren't valid
isValid = 0;
isRunning = 0;

% a while loop that will end the loop when isrunning is not 0, which will
% be when a statement isn't true, like short circuiting
while isRunning == 0
    % making sure it is a letter
    if isletter(guessesColors)
        % making sure there is 4 letters
        if length(guessesColors) == 4
            % making sure it is a member of the validLetters
            if ismember(guessesColors,validLetters)
                % stating the fact it is not valid and making sure the loop
                % won't run
            else
                isValid = 3;
                isRunning = 1;

            end
            % stating the fact it is not valid and making sure the loop
            % won't run
        else
            isValid = 2;
            isRunning = 1;
        end
        % stating the fact it is not valid and making sure the loop
        % won't run
    else
        isValid = 1;
        isRunning = 1;

    end
    % after all the statements are true, the isrunning will finally let the
    % while loop end
    isRunning = 1;


end

% connecting the valid counter with the function variable
validity = isValid;

end

