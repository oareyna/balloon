% Olivia Reyna, 10/20/26, 202

% ************************************************************************
% DO NOT CHANGE THIS CODE -- Line 4 to Line 28
% include it in your final submission of this main script
% ************************************************************************

figure('WindowStyle','docked');
warning('off','all'); % turns off all warning messages

%the size of the Guess Board
numTotGuesses = 10;
sizeColorGuess = 4;
% initializing the total amount of wins
numOfTotalWins = 0;

fprintf('%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\n');
fprintf('WELCOME TO THE MASTERMIND GAME!\n');
fprintf('%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\n');

% Guess Color Mapping
% Gray = 1,   Blue = 2, Green = 3; Orange = 4
% Pink = 5, Purple = 6,   Red = 7, Turquoise = 8, Yellow = 9

% Pegs Color Mapping
% black pegs = 2, white pegs = 3, Gray = 1

% initialize the Boards & display them
guessBoard = ones(numTotGuesses,sizeColorGuess);
resultsBoard = ones(numTotGuesses,sizeColorGuess);
showBoards(guessBoard, resultsBoard);

% making the secret code
codeMakerGuess = generateCodeMakerPattern();


% printing the start screen
fprintf("The codemaker has picked a four color pattern.\nYou need to guess what it is! Good luck!\n\n");
fprintf("-----------------------------------------------\n");

% starting the guess, userGuess, and whether or not the game should still
% be running
numguess = 1;
userGuess = 0;
yN = 'Y';

% while the variable still equals 'Y'
while strcmpi(yN, 'Y')

    % printing the screen for every time the user guesses
    fprintf("\nPossible colors: Blue(B), Green(G), Orange(O)\n               : Pink(K), Purple(P), Red(R)\n" + ...
        "               : Turquoise(T), Yellow(Y)\n");
    prompt = sprintf("Enter color guess#%d : ", numguess);
    % retrieving the user's input
    userGuess = upper(input(prompt, 's'));
    % checking if the user's input is valid
    valid = checkPlayerColorInput(userGuess);
    % if it is not valid, it will re prompt the user
    if valid == 1
        fprintf("Incorrect guess. Enter only letters for the colors.\n")
    elseif valid == 2
        fprintf("Incorrect guess. Invalid number of letters.\n")
    elseif valid == 3
        fprintf("Incorrect guess. Valid colors are BGOKPRTY.\n");
    else
        % if it is valid it will initialize the number of black pegs
        numBlackPegs = 0;
        newLook = '';
        newCode = '';
        % for the length of the user's guess
        for i = 1 : length(userGuess)
            % if the user's guess index and secret code's guess are the
            % same it will add the number of black pegs
            if strcmpi(userGuess(i), codeMakerGuess(i))
                numBlackPegs = numBlackPegs + 1;
            else
                % if the letter did not cause a black peg, it will be
                % put in a new variable for both the secret code and
                % the user's guess
                newLook = [newLook, userGuess(i)];
                newCode = [newCode, codeMakerGuess(i)];
            end
        end
        % gives us the user's guess
        numWhitePegs = determineWhitePegs(newLook,newCode);
        % gives us the colors
        guessBoard = updateGuessBoard(guessBoard, numguess, userGuess);
        % gives us the pegs
        resultsBoard = updateResultsBoard(resultsBoard, numguess,numBlackPegs, numWhitePegs);
        % adds to the number of guesses
        numguess = numguess + 1;
        % actually displays the colors and pegs
        showBoards(guessBoard,resultsBoard);
        % prints part of the games display

        % if the inputs are the same, it subtracts one from guesses
        % because at the end of each guess, one is added but of you win
        % it thinks you won with one extra guess
        if strcmpi(userGuess,codeMakerGuess)
            numguess = numguess - 1;
        end
        % if the inputs are the same or if the number of guesses are
        % over 10
        if strcmpi(userGuess,codeMakerGuess) || numguess > 10

            % if the number of guesses are over 10
            if numguess > 10
                % printing the statements
                fprintf("Sorry, you are out of guesses!\n");
                winOrLoss = determineGoodOrBadScreen(numguess);
                numOfTotalWins = numOfTotalWins + winOrLoss;
                yN = upper(input("Do you want to play again [Y/N] : ", 's'));
                % if you want to start again, it will put back all the
                % variables in its initial state
                if upper(yN) == 'Y'
                    % printing
                    fprintf("\nGreat, new game begins!\n")
                    fprintf("The codemaker has picked a four color pattern.\nYou need to guess what it is! Good luck!\n\n");
                    guessBoard = ones(numTotGuesses, sizeColorGuess);
                    resultsBoard = ones(numTotGuesses, sizeColorGuess);
                    showBoards(guessBoard, resultsBoard);
                    codeMakerGuess = generateCodeMakerPattern();
                    numguess = 1;

                else
                    % will just say goodbye if the user wants to quit
                    fprintf("OK, goodbye!");
                    % showing the amount of total wins
                    fprintf("Here is also the total amount of times you have won: %d", numOfTotalWins);
                    yN = 'N';

                end
            else
                % if the number of guesses are less than 5, it is an
                % impressive win
                if numguess < 5
                    fprintf("Impressive!!! You solved the code in less than 5 guesses!\n");

                end
                % normal win
                fprintf("Congratulations! You figured out the code!\n");
                % calling the creative function
                winOrLoss = determineGoodOrBadScreen(numguess);
                % adding up the number of total wins
                numOfTotalWins = numOfTotalWins + winOrLoss;
                % grabbing the user's input
                prompt2 = input("Do you want to play again [Y/N] : ", 's');

                % if the user picks yes
                if upper(prompt2) == 'Y'
                    % printing
                    fprintf("\nGreat, new game begins!\n\n")
                    fprintf("The codemaker has picked a four color pattern.\nYou need to guess what it is! Good luck!\n\n");
                    % restarting variables
                    guessBoard = ones(numTotGuesses, sizeColorGuess);
                    resultsBoard = ones(numTotGuesses, sizeColorGuess);
                    showBoards(guessBoard, resultsBoard);
                    codeMakerGuess = generateCodeMakerPattern();
                    numguess = 1;

                else
                    % printing
                    fprintf("OK, goodbye!\n");
                    % printing out the total number of wins
                    fprintf("Here is also the total amount of times you have won: %d", numOfTotalWins);
                    yN = 'N';

                end


            end

            fprintf("\n-----------------------------------------------\n");

        end


    end

end







